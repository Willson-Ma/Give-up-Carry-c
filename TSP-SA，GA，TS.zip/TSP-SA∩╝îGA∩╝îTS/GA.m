clear
clc

[city_n,city_position]=Read('att48.tsp.txt')    

distance=zeros(city_n);

%calculate the pseudo-Euclidean distance  
for i=1:city_n  
    for j=1:city_n
        distance(i,j)=ceil(sqrt(((city_position(i,1)-city_position(j,1))^2+(city_position(i,2)-city_position(j,2))^2)/10)); 
    end  
end

Sn_0=30; %start number  

max_generation=10000;  %max generation  

cross_pro=0.9; %Cross probability  

mutation_pro=0.3; %Mutation probability 

current_gen=zeros(30,48);  

cross_new=zeros(30,48);  

mutation_new=zeros(30,48);

flag=0;


%initial population  
initial_population=zeros(30,48);  

for i=1:30 
    initial_population(i,:)=randperm(48);  
end  

[~,p]=zxm(initial_population,distance);  
  
Sn_1=1;  

y_mean=zeros(1,1);  

y_max=zeros(1,1);  

while Sn_1 < max_generation &&  flag < 3000
    
   for j=1:2:Sn_0  
      Selected_gen=rou_select(p);  %select  
      Selected_cross=cross_sol(initial_population,Selected_gen,cross_pro);  %cross 
      cross_new(j,:)=Selected_cross(1,:);  
      cross_new(j+1,:)=Selected_cross(2,:);  
      mutation_new(j,:)=Mutation(cross_new(j,:),mutation_pro);  %mutation 
      mutation_new(j+1,:)=Mutation(cross_new(j+1,:),mutation_pro);  
   end  
   
   initial_population=mutation_new;  %new population 
   
   [f,p]=zxm(initial_population,distance);  %new populations' fitness  
   
   %the best and average fitness of the current generation 
   [a,b]=max(f);  
   
   y_mean(Sn_1)=1000/mean(f); 
   
   y_max(Sn_1)=1000/a;  
   
   %current best individual 
   x=initial_population(b,:);  
   
   current_gen(Sn_1,:)=x;  
   
   Sn_1 = Sn_1 + 1;  
   flag = flag + 1;
end

[min_y,index]=min(y_max);  

drawTSP(city_position,current_gen(index,:),min_y,flag);

%draw picture
function drawTSP(gene_list,current_bs,globle_bs_distance,p)
CityNum=size(gene_list,1);  
for i=1:CityNum-1  
    plot([gene_list(current_bs(i),1),gene_list(current_bs(i+1),1)],[gene_list(current_bs(i),2),gene_list(current_bs(i+1),2)],'ko-');   
    hold on;  
end  
plot([gene_list(current_bs(CityNum),1),gene_list(current_bs(1),1)],[gene_list(current_bs(CityNum),2),gene_list(current_bs(1),2)],'ko-');  
title(['The approximate shortest path is: ',num2str(globle_bs_distance),',Number of iterations:',num2str(p),]);  
 
end 
 

%fitness 
function F=cal_list(dislist,s)  
  
r=0;  
n=size(s,2);  
for i=1:(n-1)  
    r=r+dislist(s(i),s(i+1));
end  
r=r+dislist(s(n),s(1));  
F=r;  
end

%income initialization population and distance
function [q,w]=zxm(s,distance_list)
  
ini_size=size(s,1);  %initialization size  
q=zeros(ini_size,1);  
for i=1:ini_size  
   q(i)=cal_list(distance_list,s(i,:));  %calculate fitness  
end  
q=1000./q';  
  
%calculate the probability of an individual being selected based on their fitness  
sum=0;  
for i=1:ini_size  
   sum=sum+q(i)^15; 
end  
e=zeros(ini_size,1);  
for i=1:ini_size  
   e(i)=q(i)^15/sum;  
end  
  
% calculation sum of p
w=zeros(ini_size,1);  
w(1)=e(1);  
for i=2:ini_size  
   w(i)=w(i-1)+e(i);  
end  
w=w';  
end  

%Roulette selection
function d=rou_select(p)  
d=zeros(2,1);  

%select two individuals as parents 
for i=1:2  
   r=mod(randi([1,65535]),1000)/1000.0;  
   v=p-r;  
   j=1;  
   while v(j)<0  
       j=j+1;  
   end  
   d(i)=j;   
   
   %%exclude the possibility of selecting to the same individual 
   if i==2&&j==d(i-1)    
       r=rand;    
       v=p-r;
       j=1;
       while v(j)<0  
           j=j+1;  
       end  
   end  
end  
end  

function Cross=probability(cross_probability)  
    test(1:100)=0;  
    l=round(100*cross_probability);  
    test(1:l)=1;  
    n=round(rand*99)+1;  
    Cross=test(n);     
end  


%Mutation 
function new_p=Mutation(new_pop,mutation_probability)  
 
new_p=new_pop;  

%decide whether to do mutation operation according to mutation probability
m_p=probability(mutation_probability);   
if m_p==1  
    % produce mutation seat
   x=mod(randi([65535]),48);  
   y=mod(randi([65535]),48);  
   x1=min(x,y);  
   y1=max(x,y);  
   x=new_pop(x1+1:y1);  
   new_p(x1+1:y1)=fliplr(x);  
end  
end  


%Cross  
function Cross_Sol=cross_sol(s,new_pop,cross_probability)  
t0=size(s,2);  

%decide whether to do cross operation according to cross probability
cross_pro=probability(cross_probability);   
Cross_Sol(1,:)=s(new_pop(1),:);  
Cross_Sol(2,:)=s(new_pop(2),:); 
if cross_pro==1  
    % produce cross seat 
   x=mod(randi([65535]),48);  
   y=mod(randi([65535]),48);  
   x1=min(x,y);  
   y1=max(x,y);  
   mean=Cross_Sol(1,x1+1:y1);  
   Cross_Sol(1,x1+1:y1)=Cross_Sol(2,x1+1:y1);  
   Cross_Sol(2,x1+1:y1)=mean;  
   
   for i=1:x1  
       while find(Cross_Sol(1,x1+1:y1)==Cross_Sol(1,i))  
           mzx=find(Cross_Sol(1,x1+1:y1)==Cross_Sol(1,i));  
           y=Cross_Sol(2,x1+mzx);  
           Cross_Sol(1,i)=y;  
       end  
       while find(Cross_Sol(2,x1+1:y1)==Cross_Sol(2,i))  
           mzx=find(Cross_Sol(2,x1+1:y1)==Cross_Sol(2,i));  
           y=Cross_Sol(1,x1+mzx);  
           Cross_Sol(2,i)=y;  
       end  
   end  
   
   for i=y1+1:t0  
       while find(Cross_Sol(1,1:y1)==Cross_Sol(1,i))  
           mzx=logical(Cross_Sol(1,1:y1)==Cross_Sol(1,i));  
           y=Cross_Sol(2,mzx);  
           Cross_Sol(1,i)=y;  
       end  
       while find(Cross_Sol(2,1:y1)==Cross_Sol(2,i))  
           mzx=logical(Cross_Sol(2,1:y1)==Cross_Sol(2,i));  
           y=Cross_Sol(1,mzx);  
           Cross_Sol(2,i)=y;  
       end  
   end  
end  
end  

%read file
function [ncitys,cityposition] = Read(filename)
fid = fopen(filename,'rt');
location=[];
A = [1 2];
tline = fgetl(fid);
while ischar(tline)
    if(strcmp(tline,'NODE_COORD_SECTION'))
        while ~isempty(A)
            A=fscanf(fid,'%f',[3,1]);
            if isempty(A)
                break;
            end
            location=[location;A(2:3)'];
        end
    end
    tline = fgetl(fid); 
    if strcmp(tline,'EOF')
        break;
    end
end
[g,h]=size(location);
ncitys = g;
cityposition=location;
fclose(fid);
end