clear
clc

[city_n,city_position]=Read('att48.tsp.txt')

distance=zeros(city_n); 

%calculate the pseudo-Euclidean distance
for i=1:city_n
    for j=1:city_n
        distance(i,j)=ceil(sqrt(((city_position(i,1)-city_position(j,1))^2+(city_position(i,2)-city_position(j,2))^2)/10));       
    end
end

tabu_list=zeros(city_n);   %create tabulist

tabu_len=200;     

candidates_sol=400;   %candidate solutions

candidate_num=zeros(candidates_sol,city_n);  

solution_1=randperm(city_n);     

cur_best_sol=solution_1;   %current best solution

best_dis=Inf;   %current best distance

flag=1;    %iterations

max_ite=10000;    %maximum iterations


%tabu search loop
 while flag < max_ite && flag < 3000
     if candidates_sol>city_n*(city_n-1)/2
         disp('The number of candidate solutions is not more than n * (n-1) / 2!');
         break;
     end
     
     ALong(flag)=Fun(distance,solution_1);      %current solutions' fitness
    
    i=1;
    
    matrix_1=zeros(candidates_sol,2);         

    while i<=candidates_sol        
        M=city_n*rand(1,2);
        M=ceil(M);
        if M(1)~=M(2)
            matrix_1(i,1)=max(M(1),M(2));
            matrix_1(i,2)=min(M(1),M(2));
                if i==1
                index=0;
            else
                for j=1:i-1
                    if matrix_1(i,1)==matrix_1(j,1) && matrix_1(i,2)==matrix_1(j,2)
                        index=1;
                        break;
                    else
                        index=0;
                    end
                end
            end 
            if ~index
               i=i+1;
            else 
            end            
        else 
        end
    end
    
    %obtain domain solution
    best_candi_num=100;   %keep the best candidates
    best_candi=Inf*ones(best_candi_num,4);
    F=zeros(1,candidates_sol);
    
    for i=1:candidates_sol
        candidate_num(i,:)=solution_1;  %candidates group
        candidate_num(i,[matrix_1(i,2),matrix_1(i,1)])=solution_1([matrix_1(i,1),matrix_1(i,2)]);
        F(i)=Fun(distance,candidate_num(i,:));
        if i<=best_candi_num
            best_candi(i,2)=F(i);
            best_candi(i,1)=i;
            best_candi(i,3)=solution_1(matrix_1(i,1));
            best_candi(i,4)=solution_1(matrix_1(i,2));   
        else
            for j=1:best_candi_num
                if F(i)<best_candi(j,2)
                    best_candi(j,2)=F(i);
                    best_candi(j,1)=i;
                    best_candi(j,3)=solution_1(matrix_1(i,1));
                    best_candi(j,4)=solution_1(matrix_1(i,2));
                    break;
                end            
            end
        end
    end
   
    [list,Index]=sort(best_candi(:,2)); 
    best_sol=best_candi(Index,:);
    best_candi=best_sol;
    
    %tabu standard
      if best_candi(1,2)<best_dis
        best_dis=best_candi(1,2);
        solution_1=candidate_num(best_candi(1,1),:);        
        cur_best_sol=solution_1;
        
        for m=1:city_n
            for n=1:city_n
                if tabu_list(m,n)~=0
                    tabu_list(m,n)=tabu_list(m,n)-1;   % update tabu list
                end
            end
        end
        
        tabu_list(best_candi(1,3),best_candi(1,4))=tabu_len;   
    else  
        
for i=1:best_candi_num
            if  tabu_list(best_candi(i,3),best_candi(i,4))==0
                solution_1=candidate_num(best_candi(i,1),:);    
                
            for m=1:city_n
                for n=1:city_n
                    if tabu_list(m,n)~=0
                        tabu_list(m,n)=tabu_list(m,n)-1;   % update tabu list
                    end
                end
            end        
            
            tabu_list(best_candi(i,3),best_candi(i,4))=tabu_len;       
            break;
            end
        end
      end

     flag=flag+1;                                                          
 end

 for i=1:city_n-1
         plot([city_position(cur_best_sol(i),1),city_position(cur_best_sol(i+1),1)],[city_position(cur_best_sol(i),2),city_position(cur_best_sol(i+1),2)],'ko-');
         hold on;
 end
plot([city_position(cur_best_sol(city_n),1),city_position(cur_best_sol(1),1)],[city_position(cur_best_sol(city_n),2),city_position(cur_best_sol(1),2)],'ko-');
title([' The approximate shortest path is:',num2str(best_dis),',Number of iterations:',int2str(flag)]);

%fitness function
function F=Fun(dislist,s)   
DistanV=0;
n=size(s,2);
for i=1:(n-1)
    DistanV=DistanV+dislist(s(i),s(i+1));
end
    DistanV=DistanV+dislist(s(n),s(1));      
F=DistanV;

end


%read file
function [n_citys,city_position] = Read(filename)
fid = fopen(filename,'rt');
location=[];
A = [1 2];
tline = fgetl(fid);
while ischar(tline)
    if(strcmp(tline,'NODE_COORD_SECTION'))
        while ~isempty(A)
            A=fscanf(fid,'%f',[3,1]);
            if isempty(A)
                break;
            end
            location=[location;A(2:3)'];
        end
    end
    tline = fgetl(fid); 
    if strcmp(tline,'EOF')
        break;
    end
end
[g,h]=size(location);
n_citys = g;
city_position=location;
fclose(fid);
end













